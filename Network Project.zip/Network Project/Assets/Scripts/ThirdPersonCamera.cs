﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

// public class ThirdPersonCamera : NetworkBehaviour {
//     [SerializeField]
//     private Transform followCamTransform;
//     [SerializeField]
//     private float distanceUp = 10.0f;
//     [SerializeField]
//     private float distanceAway = 20.0f;
//     [SerializeField]
//     private float smooth = 5.0f;
//     // [SerializeField]
//     // private Transform follow;
//     private Vector3 targetPosition;

//   	// Use this for initialization
//   	void Start () {
//   		  // follow = GameObject.Find("Follow Anchor").transform;
//   	}

//   	// Update is called once per frame
//   	void Update () {

//   	}

//     void LateUpdate () {
//         if(followCamTransform != null && isLocalPlayer){
//             // Set postion of the camera
//             targetPosition = transform.position + transform.up * distanceUp - transform.forward * distanceAway;
//             Debug.DrawRay(transform.position, transform.up * distanceUp, Color.red);
//             Debug.DrawRay(transform.position, -1f * transform.forward * distanceAway, Color.blue);
//             Debug.DrawLine(transform.position, targetPosition, Color.magenta);

//             // Make a smooth transition between the location
//             followCamTransform.position = Vector3.Lerp(followCamTransform.position, targetPosition, Time.deltaTime * smooth);

//             followCamTransform.LookAt(transform);

//         }
//     }

//     public void SetFollowCamTransform(Transform trans)
//     {
//         if(isLocalPlayer){
//           followCamTransform = trans;
//         }
//     }
// }
public class ThirdPersonCamera : MonoBehaviour {
    [SerializeField]
    private Transform followCamTransform;
    [SerializeField]
    private float distanceUp = 10.0f;
    [SerializeField]
    private float distanceAway = 20.0f;
    [SerializeField]
    private float smooth = 5.0f;
    // [SerializeField]
    // private Transform follow;
    private Vector3 targetPosition;

    // Use this for initialization
    void Start () {
        // follow = GameObject.Find("Follow Anchor").transform;
    }

    // Update is called once per frame
    void Update () {

    }

    void LateUpdate () {
        if(followCamTransform != null){
            // Set postion of the camera
            targetPosition = transform.position + transform.up * distanceUp - transform.forward * distanceAway;
            Debug.DrawRay(transform.position, transform.up * distanceUp, Color.red);
            Debug.DrawRay(transform.position, -1f * transform.forward * distanceAway, Color.blue);
            Debug.DrawLine(transform.position, targetPosition, Color.magenta);

            // Make a smooth transition between the location
            followCamTransform.position = Vector3.Lerp(followCamTransform.position, targetPosition, Time.deltaTime * smooth);

            followCamTransform.LookAt(transform);

        }
    }

    public void SetFollowCamTransform(Transform trans)
    {
        followCamTransform = trans;
        // if(isLocalPlayer){
        //   followCamTransform = trans;
        // }
    }
}
// public class ThirdPersonCamera : MonoBehaviour {

//     [SerializeField]
//     private float distanceUp = 10.0f;
//     [SerializeField]
//     private float distanceAway = 20.0f;
//     [SerializeField]
//     private float smooth = 5.0f;
//     [SerializeField]
//     private Transform follow;
//     private Vector3 targetPosition;

//     // Use this for initialization
//     void Start () {
//         // follow = GameObject.Find("Follow Anchor").transform;
//     }

//     // Update is called once per frame
//     void Update () {

//     }

//     void LateUpdate () {
//         if(follow != null){
//             // Set postion of the camera
//             targetPosition = follow.position + follow.up * distanceUp - follow.forward * distanceAway;
//             Debug.DrawRay(follow.position, follow.up * distanceUp, Color.red);
//             Debug.DrawRay(follow.position, -1f * follow.forward * distanceAway, Color.blue);
//             Debug.DrawLine(follow.position, targetPosition, Color.magenta);

//             // Make a smooth transition between the location
//             transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * smooth);

//             transform.LookAt(follow);

//         }
//     }

//     public void SetFollow(Transform trans)
//     {
//         follow = trans;
//     }
// }