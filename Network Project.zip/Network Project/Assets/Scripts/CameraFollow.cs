﻿using UnityEngine;
using System.Collections;

public class CameraFollow : MonoBehaviour
{
    public Transform target;            // The position that that camera will be following.
    public float smoothing = 5f;        // The speed with which the camera will be following.
    // Vector3 offset = new Vector3(0,10,-20);                     // The initial offset from the target.
    Vector3 offset;
    void Start ()
    {
        if(target != null)
        {
            // Calculate the initial offset.
            offset = transform.position - target.position;
            // transform.position = target.position + offset;
            // transform.rotation = Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, target.rotation.eulerAngles.y, transform.rotation.eulerAngles.z));
        }
        // transform.position = target.position + offset;
    }

    void LateUpdate ()
    {
        if(target != null)
        {
            // Create a position the camera is aiming for based on the offset from the target.
            Vector3 targetCamPos = target.position + offset;
            // Vector3 targetCamPos = target.position + new Vector3(0,10,depth);
            // Smoothly interpolate between the camera's current position and it's target position.
            transform.position = Vector3.Lerp (transform.position, targetCamPos, smoothing * Time.deltaTime);
            // transform.rotation = Quaternion.Lerp(transform. rotation, Quaternion.Euler(new Vector3(transform.rotation.eulerAngles.x, target.rotation.eulerAngles.y, transform.rotation.eulerAngles.z)), smoothing * Time.deltaTime);
            transform.LookAt(target);
        }
    }

    public void SetTarget(Transform transTarget)
    {
       target = transTarget;
    }
}