﻿using UnityEngine;
using UnityEngine.Networking;

public class PlayerController : NetworkBehaviour
{
    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    [SerializeField]
    private float distanceUp = 10.0f;
    [SerializeField]
    private float distanceAway = 10.0f;

    void Start ()
    {
        if (isLocalPlayer)
        {
            // Solution to camera following user is from https://www.youtube.com/watch?v=wvUNXkrEMys
            GameObject.Find("Main Camera").transform.position = transform.position + transform.up * distanceUp - transform.forward * distanceAway;
            GameObject.Find("Main Camera").transform.LookAt(transform);
            GameObject.Find("Main Camera").transform.parent = transform;
        }
    }

    void Update()
    {
        if (!isLocalPlayer)
        {
            return;
        }

        MoveUser();

        if (Input.GetKeyDown(KeyCode.Space))
        {
            CmdFire();
        }
    }

    void MoveUser(){
        var x = Input.GetAxis("Horizontal") * Time.deltaTime * 150.0f;
        var z = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;

        transform.Rotate(0, x, 0);
        transform.Translate(0, 0, z);
    }
    // This [Command] code is called on the Client …
    // … but it is run on the Server!
    [Command]
    void CmdFire()
    {
        // Create the Bullet from the Bullet Prefab
        var bullet = (GameObject)Instantiate(
            bulletPrefab,
            bulletSpawn.position,
            bulletSpawn.rotation);

        // Add velocity to the bullet
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * 6;

        // Spawn the bullet on the Clients
        NetworkServer.Spawn(bullet);

        // Destroy the bullet after 2 seconds
        Destroy(bullet, 3.0f);
    }

    public override void OnStartLocalPlayer ()
    {
        GetComponent<MeshRenderer>().material.color = Color.blue;
        // GameObject.Find("Follow Camera").GetComponent<ThirdPersonCamera>().SetFollow(gameObject.transform);
        // GetComponent<ThirdPersonCamera>().SetFollowCamTransform(GameObject.Find("Follow Camera").transform);
    }
}